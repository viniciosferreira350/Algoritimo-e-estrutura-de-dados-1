// Matrícula: D31279
// Nome: Vinicios Ferreira da Silva

public class C09EX11d {
    public static void main(String[] args) {
        double serie = 0;
        for (int aux = 1; aux <= 100; aux++) {
            serie += Math.pow(aux, 3) / Math.pow(10.0, aux - 1);
        }
        System.out.println("D = " + serie);
    }
}
