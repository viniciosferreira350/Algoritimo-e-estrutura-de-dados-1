// Matrícula: D31279
// Nome: Vinicios Ferreira da Silva

public class C09EX01 {
    public static void main(String[] args) {
        double serie = 0;
        for (int aux = 1; aux <= 37; aux++) {
            double num = (38.0 - aux) * (39.0 - aux);
            double den = aux;
            serie += num / den;
        }
        System.out.println("Valor da Série = " + serie);
    }
}
