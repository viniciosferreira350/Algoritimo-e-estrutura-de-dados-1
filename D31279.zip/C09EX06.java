// Matrícula: D31279
// Nome: Vinicios Ferreira da Silva

public class C09EX06 {
    public static void main(String[] args) {
        double soma = 0, serie;
        for (int aux = 1; aux <= 20; aux++) {
            double num = aux;
            double den = Math.sqrt(2.0 * aux);
            soma += num / den;
        }
        serie = 10.0 + soma;
        System.out.println("Valor da Série = " + serie);
    }
}
